/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package my.integraleditor;

/**
 *
 * @author Ilya
 */
class InvalidValueException extends Exception {
    public InvalidValueException(String message) {
        super(message); 
    }
}
